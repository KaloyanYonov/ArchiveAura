<?php session_start(); ?>

<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles/style2.css">
    <title>ArchiveAura</title>
</head>

<body>

     <div class="container">
        <h1 class="fade-in">Welcome to Web Archiver!</h1>

        <a href="php/get_started.php" class="btn fade-in">
            Get Started
        </a>
    </div>

</body>

</html>
